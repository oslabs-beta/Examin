chrome.devtools.panels.create('Examin', null, '/panel.html', null);
